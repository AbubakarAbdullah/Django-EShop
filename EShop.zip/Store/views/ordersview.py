from django.shortcuts import render, redirect

from django.contrib.auth.hashers import check_password
from Store.models.customer import Customer
from django.views import View

from Store.models.product import Product
from Store.models.orders import Order
class OrdersView(View):

    def get(self, request):
        customer = request.session.get('customer')
        order = Order.get_orders_by_customer(customer)

        return render(request, 'orders.html', {'orders' : order})